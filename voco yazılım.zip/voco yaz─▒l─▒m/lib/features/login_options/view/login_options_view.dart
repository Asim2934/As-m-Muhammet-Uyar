import 'package:flutter/material.dart';
import 'package:flutter_login_types/core/theme/colors.dart';
import 'package:flutter_login_types/core/widgets/custom_button.dart';
import 'package:flutter_login_types/l10n/l10n.dart';
import 'package:go_router/go_router.dart';

class LoginOptionsView extends StatelessWidget {
  const LoginOptionsView({super.key});

  @override
  Widget build(BuildContext context) {
    final localization = context.localizations;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black,
        title: Text(
          localization.signInOptionText,
          textAlign: TextAlign.center,
          style: const TextStyle(color: CustomColors.darkBlue, fontSize: 20),
        ),
      ),
      backgroundColor: CustomColors.white,
      body: const Padding(
        padding: EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            _SimpleLoginButton(),
            SizedBox(height: 20),
            _PasscodeButton(),
            SizedBox(height: 20),
            _FingerprintButton(),
            SizedBox(height: 20),
            _ThirdLoginButton(),
            SizedBox(height: 20),
            _MechanismLoginButton(),
          ],
        ),
      ),
    );
  }
}

class _SimpleLoginButton extends StatelessWidget {
  const _SimpleLoginButton();

  @override
  Widget build(BuildContext context) {
    final localization = context.localizations;

    return CustomButton(
      text: localization.signInText(localization.signInUserPassword),
      onPress: () => context.go('/login_user_pass'),
      backgroundColor: CustomColors.white.withOpacity(.6),
      foregroundColor: CustomColors.darkBlue,
      icon: const Icon(Icons.login, color: CustomColors.darkBlue),
    );
  }
}

class _PasscodeButton extends StatelessWidget {
  const _PasscodeButton();

  @override
  Widget build(BuildContext context) {
    final localization = context.localizations;

    return CustomButton(
      text: localization.signInText(localization.signInPasscode),
      onPress: () => context.go('/login_passcode'),
      backgroundColor: CustomColors.lightBlue,
      foregroundColor: CustomColors.white,
      icon: const Icon(Icons.sms_outlined, color: CustomColors.white),
    );
  }
}

class _FingerprintButton extends StatelessWidget {
  const _FingerprintButton();

  @override
  Widget build(BuildContext context) {
    final localization = context.localizations;

    return CustomButton(
      text: localization.signInText(localization.signInFingerPrint),
      onPress: () => context.go('/login_biometric'),
      backgroundColor: CustomColors.darkPurple,
      foregroundColor: CustomColors.white,
      icon: const Icon(Icons.fingerprint_outlined, color: CustomColors.white),
    );
  }
}

class _ThirdLoginButton extends StatelessWidget {
  const _ThirdLoginButton();

  @override
  Widget build(BuildContext context) {
    final localization = context.localizations;

    return CustomButton(
      text: localization.signInText(localization.signInThird),
      onPress: () => context.go('/third_login'),
      backgroundColor: CustomColors.darkYellow,
      foregroundColor: CustomColors.white,
      icon: const Icon(
        Icons.account_circle_outlined,
        color: CustomColors.white,
      ),
    );
  }
}

class _MechanismLoginButton extends StatelessWidget {
  const _MechanismLoginButton();

  @override
  Widget build(BuildContext context) {
    final localization = context.localizations;

    return CustomButton(
      text: localization.signInText(localization.signInOtherMechanism),
      onPress: () => context.go('/mechanism_login'),
      backgroundColor: CustomColors.lightRed,
      foregroundColor: CustomColors.white,
      icon: const Icon(Icons.account_balance, color: CustomColors.white),
    );
  }
}
